package com.example.studentend;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Attendence extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendence);
    }
}
