package com.example.studentend.CustomizedClass;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by GCG on 2017/5/4.
 */

public class CustomizedActivity extends AppCompatActivity {
    public void updateUI(Object backtaskanswer,int ViewID){

    }
}
