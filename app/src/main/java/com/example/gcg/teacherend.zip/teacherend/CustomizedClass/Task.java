package com.example.gcg.teacherend.CustomizedClass;

/**
 * Created by GCG on 2017/5/19.
 */

public class Task {
    private String title;
    private String detail;

    public String getTitle() {
        return title;
    }

    public String getDetail() {
        return detail;
    }

    public Task(String title,String detail){
        this.title = title;
        this.detail = detail;
    }

}
