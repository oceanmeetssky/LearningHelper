package com.example.gcg.teacherend.CustomizedClass;

import android.support.v7.app.AppCompatActivity;

import com.example.gcg.teacherend.CustomizedClass.RecitingWebService;

/**
 * Created by GCG on 2017/5/4.
 */

public class CustomizedActivity extends AppCompatActivity {
    public void updateUI(Object backtaskanswer,int ViewID){

    }
}
