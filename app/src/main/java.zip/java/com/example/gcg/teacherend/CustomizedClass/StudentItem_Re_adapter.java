package com.example.gcg.teacherend.CustomizedClass;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

import com.example.gcg.teacherend.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by GCG on 2017/5/29.
 */
/*
public class StudentItem_Re_adapter extends RecyclerView.Adapter<TaskFileAdapter.ViewHolder> {
    private List<StudentItem> studentItemList;

    public StudentItem_Re_adapter(List<TaskFile> taskFileList){
        this.taskFileList = taskFileList;
        fileList = new ArrayList<MyFile>();
    }

    static class ViewHolder extends RecyclerView.ViewHolder{
        View StudentView;//保存子项最外层布局的实例
        TextView textView_sno;
        TextView textView_sname;

        public ViewHolder(View itemView) {
            super(itemView);
            StudentView = itemView;
            textView_sno = (TextView) itemView.findViewById(R.id.textview_sno);
            textView_sname = (TextView) itemView.findViewById(R.id.textView_sname);
        }
    }
}
*/